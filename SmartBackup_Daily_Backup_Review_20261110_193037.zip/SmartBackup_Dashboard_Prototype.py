from __future__ import annotations

import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pathlib import Path


APP_TITLE = "SmartBackup"
DEVELOPER = "Developed by Saiful Quadir"

COLORS = {
    "bg": "#0B1220",
    "sidebar": "#0E1728",
    "panel": "#121F33",
    "panel_alt": "#17263D",
    "panel_hover": "#1B2D47",
    "border": "#263851",
    "text": "#EDF3FA",
    "muted": "#9AABC0",
    "subtle": "#6F829B",
    "accent": "#39D6B4",
    "accent_dark": "#153F3B",
    "blue": "#75B7FF",
    "blue_dark": "#1B3553",
    "amber": "#F1C56B",
    "amber_dark": "#49391D",
    "red": "#FF7C88",
    "red_dark": "#48232D",
    "white": "#FFFFFF",
}

FONT = "Helvetica Neue"
MONO = "Menlo"

HOME = Path.home()
DAILY_SOURCES = [HOME / "Documents", HOME / "Downloads"]
DAILY_DESTINATIONS = {
    "Local": HOME / "Documents",
    "iCloud Drive": HOME / "Library/Mobile Documents/com~apple~CloudDocs/SmartBackup",
    "OneDrive": HOME / "Library/CloudStorage/OneDrive-Personal(2) 2/SmartBackup",
}
MANUAL_DESTINATIONS = {
    "OneDrive": HOME / "Library/CloudStorage/OneDrive-Personal(2) 2/SmartBackup/Archives",
    "iCloud Drive": HOME / "Library/Mobile Documents/com~apple~CloudDocs/SmartBackup/Archives",
    "Windows D: ADATA": Path("/Volumes/Windows_D_ADATA/DATA/SmartBackup_Archives"),
    "Windows F: Transcend": Path("/Volumes/Windows_F_TRANSCEND/SmartBackup_Archives"),
    "Local Mac": HOME / "Documents/SmartBackup/Archives",
}


class SmartBackupDashboard:
    """UI-only prototype. No backup, sync, delete, or network operations are connected."""

    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title(f"{APP_TITLE} | Backup Command Center")
        self.root.geometry("1280x860")
        self.root.minsize(1080, 720)
        self.root.configure(bg=COLORS["bg"])

        self.selected_source = tk.StringVar(value="")
        self.destination_vars = {
            name: tk.BooleanVar(value=(name == "OneDrive"))
            for name in MANUAL_DESTINATIONS
        }
        self.current_page = "overview"
        self.content: tk.Frame | None = None
        self.nav_buttons: dict[str, tk.Button] = {}

        self._configure_ttk()
        self._build_shell()
        self.show_page("overview")

    def _configure_ttk(self) -> None:
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(
            "Smart.Horizontal.TProgressbar",
            troughcolor=COLORS["panel_alt"],
            background=COLORS["accent"],
            bordercolor=COLORS["panel_alt"],
            lightcolor=COLORS["accent"],
            darkcolor=COLORS["accent"],
            thickness=12,
        )
        style.configure(
            "Smart.Treeview",
            background=COLORS["panel"],
            fieldbackground=COLORS["panel"],
            foreground=COLORS["text"],
            bordercolor=COLORS["border"],
            rowheight=34,
            font=(FONT, 10),
        )
        style.configure(
            "Smart.Treeview.Heading",
            background=COLORS["panel_alt"],
            foreground=COLORS["muted"],
            relief="flat",
            font=(FONT, 9, "bold"),
        )
        style.configure(
            "Vertical.TScrollbar",
            background=COLORS["panel_alt"],
            troughcolor=COLORS["bg"],
            bordercolor=COLORS["bg"],
            arrowcolor=COLORS["muted"],
            darkcolor=COLORS["panel_alt"],
            lightcolor=COLORS["panel_alt"],
            relief="flat",
            width=10,
        )
        style.map(
            "Vertical.TScrollbar",
            background=[("active", COLORS["accent"])],
        )
        style.map(
            "Smart.Treeview",
            background=[("selected", COLORS["blue_dark"])],
            foreground=[("selected", COLORS["white"])],
        )

    def _build_shell(self) -> None:
        shell = tk.Frame(self.root, bg=COLORS["bg"])
        shell.pack(fill="both", expand=True)

        self.sidebar = tk.Frame(shell, bg=COLORS["sidebar"], width=238)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        main = tk.Frame(shell, bg=COLORS["bg"])
        main.pack(side="right", fill="both", expand=True)

        self._build_sidebar()
        self._build_topbar(main)

        body = tk.Frame(main, bg=COLORS["bg"])
        body.pack(fill="both", expand=True, padx=28, pady=(14, 18))

        self.canvas = tk.Canvas(
            body,
            bg=COLORS["bg"],
            highlightthickness=0,
            borderwidth=0,
        )
        self.scrollbar = ttk.Scrollbar(
            body,
            orient="vertical",
            command=self.canvas.yview,
        )
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

        self.content = tk.Frame(self.canvas, bg=COLORS["bg"])
        self.content_window = self.canvas.create_window(
            (0, 0), window=self.content, anchor="nw"
        )
        self.content.bind("<Configure>", self._update_scroll_region)
        self.canvas.bind("<Configure>", self._resize_content)
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)

    def _update_scroll_region(self, _event=None) -> None:
        if hasattr(self, "canvas") and hasattr(self, "content"):
            self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _resize_content(self, event) -> None:
        if hasattr(self, "content_window"):
            self.canvas.itemconfigure(self.content_window, width=event.width)

    def _on_mousewheel(self, event) -> None:
        if hasattr(self, "canvas"):
            self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def _build_sidebar(self) -> None:
        brand = tk.Frame(self.sidebar, bg=COLORS["sidebar"])
        brand.pack(fill="x", padx=22, pady=(28, 34))

        mark = tk.Label(
            brand,
            text="S",
            bg=COLORS["accent_dark"],
            fg=COLORS["accent"],
            font=(FONT, 19, "bold"),
            width=2,
            height=1,
            padx=5,
            pady=5,
        )
        mark.pack(side="left")

        brand_text = tk.Frame(brand, bg=COLORS["sidebar"])
        brand_text.pack(side="left", padx=(11, 0))
        tk.Label(
            brand_text,
            text="SmartBackup",
            bg=COLORS["sidebar"],
            fg=COLORS["text"],
            font=(FONT, 14, "bold"),
        ).pack(anchor="w")
        tk.Label(
            brand_text,
            text="BACKUP COMMAND CENTER",
            bg=COLORS["sidebar"],
            fg=COLORS["subtle"],
            font=(FONT, 7, "bold"),
        ).pack(anchor="w", pady=(3, 0))

        tk.Label(
            self.sidebar,
            text="WORKSPACE",
            bg=COLORS["sidebar"],
            fg=COLORS["subtle"],
            font=(FONT, 8, "bold"),
        ).pack(anchor="w", padx=23, pady=(0, 9))

        navigation = [
            ("overview", "◈", "Overview"),
            ("daily", "◷", "Daily Backup"),
            ("manual", "▣", "Manual Archive"),
            ("activity", "≋", "Activity & Reports"),
        ]
        for key, symbol, label in navigation:
            button = tk.Button(
                self.sidebar,
                text=f"  {symbol}    {label}",
                command=lambda page=key: self.show_page(page),
                anchor="w",
                relief="flat",
                bd=0,
                highlightthickness=0,
                padx=14,
                pady=12,
                bg=COLORS["sidebar"],
                fg=COLORS["muted"],
                activebackground=COLORS["panel_hover"],
                activeforeground=COLORS["text"],
                font=(FONT, 10, "bold"),
                cursor="hand2",
            )
            button.pack(fill="x", padx=12, pady=2)
            self.nav_buttons[key] = button

        spacer = tk.Frame(self.sidebar, bg=COLORS["sidebar"])
        spacer.pack(fill="both", expand=True)

        status_card = tk.Frame(
            self.sidebar,
            bg=COLORS["panel"],
            highlightbackground=COLORS["border"],
            highlightthickness=1,
        )
        status_card.pack(fill="x", padx=15, pady=(0, 17))
        tk.Label(
            status_card,
            text="SYSTEM MODE",
            bg=COLORS["panel"],
            fg=COLORS["subtle"],
            font=(FONT, 8, "bold"),
        ).pack(anchor="w", padx=13, pady=(12, 5))
        tk.Label(
            status_card,
            text="Design Preview",
            bg=COLORS["panel"],
            fg=COLORS["accent"],
            font=(FONT, 10, "bold"),
        ).pack(anchor="w", padx=13)
        tk.Label(
            status_card,
            text="Backup engine not connected",
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=(FONT, 8),
        ).pack(anchor="w", padx=13, pady=(3, 12))

        tk.Label(
            self.sidebar,
            text=DEVELOPER,
            bg=COLORS["sidebar"],
            fg=COLORS["subtle"],
            font=(FONT, 8),
        ).pack(anchor="w", padx=21, pady=(0, 17))

    def _build_topbar(self, parent: tk.Frame) -> None:
        top = tk.Frame(parent, bg=COLORS["bg"], height=74)
        top.pack(fill="x", padx=28, pady=(20, 0))
        top.pack_propagate(False)

        left = tk.Frame(top, bg=COLORS["bg"])
        left.pack(side="left", fill="y")
        self.page_title = tk.Label(
            left,
            text="Overview",
            bg=COLORS["bg"],
            fg=COLORS["text"],
            font=(FONT, 22, "bold"),
        )
        self.page_title.pack(anchor="w")
        self.page_subtitle = tk.Label(
            left,
            text="A clear view of your backup workflow and destinations.",
            bg=COLORS["bg"],
            fg=COLORS["muted"],
            font=(FONT, 9),
        )
        self.page_subtitle.pack(anchor="w", pady=(4, 0))

        pill = tk.Label(
            top,
            text="●  UI PREVIEW  ·  NO FILES WILL BE TRANSFERRED",
            bg=COLORS["amber_dark"],
            fg=COLORS["amber"],
            padx=12,
            pady=8,
            font=(FONT, 8, "bold"),
        )
        pill.pack(side="right", anchor="center", pady=8)

    def _clear_content(self) -> None:
        if self.content is not None:
            for widget in self.content.winfo_children():
                widget.destroy()

    def show_page(self, page: str) -> None:
        self.current_page = page
        self._clear_content()

        for key, button in self.nav_buttons.items():
            active = key == page
            button.configure(
                bg=COLORS["panel_hover"] if active else COLORS["sidebar"],
                fg=COLORS["accent"] if active else COLORS["muted"],
            )

        page_info = {
            "overview": ("Overview", "A clear view of your backup workflow and destinations."),
            "daily": ("Daily Backup", "Keep the existing automatic Documents and Downloads workflow."),
            "manual": ("Manual Archive", "Choose a folder, select destinations, review, and then back up."),
            "activity": ("Activity & Reports", "A single place for transfer history, results, and verification reports."),
        }
        title, subtitle = page_info[page]
        self.page_title.configure(text=title)
        self.page_subtitle.configure(text=subtitle)

        if page == "overview":
            self._build_overview()
        elif page == "daily":
            self._build_daily_page()
        elif page == "manual":
            self._build_manual_page()
        else:
            self._build_activity_page()

    def _card(self, parent: tk.Widget, padding: int = 17) -> tk.Frame:
        frame = tk.Frame(
            parent,
            bg=COLORS["panel"],
            highlightbackground=COLORS["border"],
            highlightthickness=1,
            padx=padding,
            pady=padding,
        )
        return frame

    def _section_heading(self, parent: tk.Widget, title: str, subtitle: str | None = None) -> None:
        wrapper = tk.Frame(parent, bg=COLORS["bg"])
        wrapper.pack(fill="x", pady=(0, 12))
        tk.Label(
            wrapper,
            text=title,
            bg=COLORS["bg"],
            fg=COLORS["text"],
            font=(FONT, 12, "bold"),
        ).pack(anchor="w")
        if subtitle:
            tk.Label(
                wrapper,
                text=subtitle,
                bg=COLORS["bg"],
                fg=COLORS["muted"],
                font=(FONT, 9),
            ).pack(anchor="w", pady=(3, 0))

    def _metric_card(self, parent: tk.Widget, value: str, label: str, hint: str, accent: str) -> None:
        card = self._card(parent, 16)
        card.pack(side="left", fill="both", expand=True, padx=(0, 12))
        tk.Label(card, text=value, bg=COLORS["panel"], fg=accent, font=(FONT, 23, "bold")).pack(anchor="w")
        tk.Label(card, text=label, bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 10, "bold")).pack(anchor="w", pady=(4, 0))
        tk.Label(card, text=hint, bg=COLORS["panel"], fg=COLORS["muted"], font=(FONT, 8)).pack(anchor="w", pady=(5, 0))

    def _action_button(self, parent: tk.Widget, text: str, command, primary: bool = True, width: int | None = None) -> tk.Button:
        bg = COLORS["accent"] if primary else COLORS["panel_alt"]
        fg = COLORS["bg"] if primary else COLORS["text"]
        button = tk.Button(
            parent,
            text=text,
            command=command,
            bg=bg,
            fg=fg,
            activebackground=COLORS["blue"] if primary else COLORS["panel_hover"],
            activeforeground=COLORS["bg"] if primary else COLORS["text"],
            relief="flat",
            bd=0,
            highlightthickness=0,
            padx=16,
            pady=10,
            font=(FONT, 9, "bold"),
            cursor="hand2",
            width=width,
        )
        return button

    def _build_overview(self) -> None:
        assert self.content is not None
        hero = tk.Frame(self.content, bg=COLORS["panel_alt"], padx=24, pady=22)
        hero.pack(fill="x", pady=(0, 17))
        hero_left = tk.Frame(hero, bg=COLORS["panel_alt"])
        hero_left.pack(side="left", fill="both", expand=True)
        tk.Label(
            hero_left,
            text="Your backups. Organized.",
            bg=COLORS["panel_alt"],
            fg=COLORS["text"],
            font=(FONT, 20, "bold"),
        ).pack(anchor="w")
        tk.Label(
            hero_left,
            text="Run your regular daily backup or create a one-time archive to the destination you choose.",
            bg=COLORS["panel_alt"],
            fg=COLORS["muted"],
            font=(FONT, 9),
            wraplength=650,
            justify="left",
        ).pack(anchor="w", pady=(7, 0))
        self._action_button(hero, "OPEN MANUAL ARCHIVE  →", lambda: self.show_page("manual"), True).pack(side="right", padx=(15, 0), pady=10)

        metrics = tk.Frame(self.content, bg=COLORS["bg"])
        metrics.pack(fill="x", pady=(0, 23))
        self._metric_card(metrics, "02", "Backup modes", "Daily Backup + Manual Archive", COLORS["blue"])
        self._metric_card(metrics, "05", "Manual destinations", "Local, iCloud, OneDrive, D: and F:", COLORS["accent"])
        self._metric_card(metrics, "—", "Active transfers", "Transfer engine not connected", COLORS["amber"])

        self._section_heading(self.content, "BACKUP WORKSPACE", "Choose how you want to protect your files.")
        cards = tk.Frame(self.content, bg=COLORS["bg"])
        cards.pack(fill="x", pady=(0, 22))

        daily = self._card(cards, 20)
        daily.pack(side="left", fill="both", expand=True, padx=(0, 9))
        tk.Label(daily, text="◷", bg=COLORS["panel"], fg=COLORS["blue"], font=(FONT, 22, "bold")).pack(anchor="w")
        tk.Label(daily, text="Daily Smart Backup", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 14, "bold")).pack(anchor="w", pady=(8, 5))
        tk.Label(
            daily,
            text="Automatically scan Documents and Downloads for new or modified items. Keep the familiar review and approval process.",
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=(FONT, 9),
            wraplength=390,
            justify="left",
        ).pack(anchor="w", pady=(0, 15))
        tk.Label(daily, text="LOCAL   ·   iCLOUD   ·   ONEDRIVE", bg=COLORS["panel"], fg=COLORS["blue"], font=(FONT, 8, "bold")).pack(anchor="w", pady=(0, 13))
        self._action_button(daily, "OPEN DAILY BACKUP  →", lambda: self.show_page("daily"), False).pack(anchor="w")

        manual = self._card(cards, 20)
        manual.pack(side="left", fill="both", expand=True, padx=(9, 0))
        tk.Label(manual, text="▣", bg=COLORS["panel"], fg=COLORS["accent"], font=(FONT, 22, "bold")).pack(anchor="w")
        tk.Label(manual, text="Manual Archive Backup", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 14, "bold")).pack(anchor="w", pady=(8, 5))
        tk.Label(
            manual,
            text="Browse to any folder, choose one or more destinations, review the selection, and monitor each file in the progress window.",
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=(FONT, 9),
            wraplength=390,
            justify="left",
        ).pack(anchor="w", pady=(0, 15))
        tk.Label(manual, text="ONEDRIVE   ·   WINDOWS D:   ·   WINDOWS F:", bg=COLORS["panel"], fg=COLORS["accent"], font=(FONT, 8, "bold")).pack(anchor="w", pady=(0, 13))
        self._action_button(manual, "CREATE MANUAL ARCHIVE  →", lambda: self.show_page("manual"), True).pack(anchor="w")

        self._section_heading(self.content, "DESTINATION OVERVIEW", "Configured locations are shown for design review; live connection checks are not yet wired.")
        self._destination_strip(self.content)

    def _destination_strip(self, parent: tk.Widget) -> None:
        row = tk.Frame(parent, bg=COLORS["bg"])
        row.pack(fill="x")
        entries = [
            ("OneDrive", "Cloud storage", COLORS["accent"]),
            ("Windows D: ADATA", "/Volumes/Windows_D_ADATA", COLORS["blue"]),
            ("Windows F: Transcend", "/Volumes/Windows_F_TRANSCEND", COLORS["amber"]),
        ]
        for name, detail, accent in entries:
            card = self._card(row, 12)
            card.pack(side="left", fill="both", expand=True, padx=(0, 9))
            tk.Label(card, text=name, bg=COLORS["panel"], fg=accent, font=(FONT, 9, "bold")).pack(anchor="w")
            tk.Label(card, text=detail, bg=COLORS["panel"], fg=COLORS["muted"], font=(FONT, 8)).pack(anchor="w", pady=(4, 0))
            tk.Label(card, text="Connection: Not checked", bg=COLORS["panel"], fg=COLORS["subtle"], font=(FONT, 8)).pack(anchor="w", pady=(7, 0))

    def _build_daily_page(self) -> None:
        assert self.content is not None
        banner = self._card(self.content, 20)
        banner.pack(fill="x", pady=(0, 16))
        tk.Label(banner, text="EXISTING WORKFLOW", bg=COLORS["panel"], fg=COLORS["blue"], font=(FONT, 8, "bold")).pack(anchor="w")
        tk.Label(banner, text="Daily Documents & Downloads Backup", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 16, "bold")).pack(anchor="w", pady=(6, 4))
        tk.Label(
            banner,
            text="The existing process remains: scan for today's new or modified items → show the review window → user approval → back up to all three daily destinations.",
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=(FONT, 9),
            wraplength=850,
            justify="left",
        ).pack(anchor="w")

        columns = tk.Frame(self.content, bg=COLORS["bg"])
        columns.pack(fill="x", pady=(0, 16))
        sources = self._card(columns, 18)
        sources.pack(side="left", fill="both", expand=True, padx=(0, 9))
        tk.Label(sources, text="SOURCE FOLDERS", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 10, "bold")).pack(anchor="w", pady=(0, 12))
        for path in DAILY_SOURCES:
            self._path_row(sources, "Folder", path)

        destinations = self._card(columns, 18)
        destinations.pack(side="left", fill="both", expand=True, padx=(9, 0))
        tk.Label(destinations, text="DAILY DESTINATIONS", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 10, "bold")).pack(anchor="w", pady=(0, 12))
        for name, path in DAILY_DESTINATIONS.items():
            self._path_row(destinations, name, path)

        note = tk.Frame(self.content, bg=COLORS["blue_dark"], padx=16, pady=13)
        note.pack(fill="x", pady=(0, 17))
        tk.Label(
            note,
            text="The current scan, manifest rules, date-wise folder structure, and three-destination approval flow will be retained when the engine is connected.",
            bg=COLORS["blue_dark"],
            fg=COLORS["text"],
            font=(FONT, 9),
            wraplength=900,
            justify="left",
        ).pack(anchor="w")

        controls = tk.Frame(self.content, bg=COLORS["bg"])
        controls.pack(fill="x")
        self._action_button(controls, "PREVIEW DAILY REVIEW WINDOW", self._show_daily_review, True).pack(side="left")
        tk.Label(controls, text="Preview only — no scan or backup is started.", bg=COLORS["bg"], fg=COLORS["subtle"], font=(FONT, 8)).pack(side="left", padx=14)

    def _path_row(self, parent: tk.Widget, label: str, path: Path) -> None:
        wrapper = tk.Frame(parent, bg=COLORS["panel"])
        wrapper.pack(fill="x", pady=5)
        tk.Label(wrapper, text=label, bg=COLORS["panel"], fg=COLORS["accent"], font=(FONT, 8, "bold"), width=15, anchor="w").pack(anchor="w")
        tk.Label(
            wrapper,
            text=str(path),
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=(MONO, 8),
            wraplength=420,
            justify="left",
        ).pack(anchor="w", pady=(3, 5))

    def _build_manual_page(self) -> None:
        assert self.content is not None
        intro = tk.Frame(self.content, bg=COLORS["bg"])
        intro.pack(fill="x", pady=(0, 15))
        tk.Label(
            intro,
            text="Select a folder and decide where it should go.",
            bg=COLORS["bg"],
            fg=COLORS["text"],
            font=(FONT, 15, "bold"),
        ).pack(anchor="w")
        tk.Label(
            intro,
            text="This mode is intended for one-time archives, large media folders, and user-selected backups.",
            bg=COLORS["bg"],
            fg=COLORS["muted"],
            font=(FONT, 9),
        ).pack(anchor="w", pady=(4, 0))

        source_card = self._card(self.content, 18)
        source_card.pack(fill="x", pady=(0, 14))
        tk.Label(source_card, text="01  SOURCE FOLDER", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 10, "bold")).pack(anchor="w")
        source_row = tk.Frame(source_card, bg=COLORS["panel"])
        source_row.pack(fill="x", pady=(12, 0))
        self.source_entry = tk.Entry(
            source_row,
            textvariable=self.selected_source,
            bg=COLORS["panel_alt"],
            fg=COLORS["text"],
            insertbackground=COLORS["text"],
            relief="flat",
            bd=0,
            font=(MONO, 9),
        )
        self.source_entry.pack(side="left", fill="x", expand=True, ipady=11, padx=(0, 10))
        self._action_button(source_row, "BROWSE FOLDER", self._browse_source, False).pack(side="right")
        tk.Label(
            source_card,
            text="Choose the complete source folder. Its internal folder structure will be preserved.",
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=(FONT, 8),
        ).pack(anchor="w", pady=(9, 0))

        destination_card = self._card(self.content, 18)
        destination_card.pack(fill="x", pady=(0, 14))
        tk.Label(destination_card, text="02  BACKUP DESTINATIONS", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 10, "bold")).pack(anchor="w")
        tk.Label(
            destination_card,
            text="Select one or more destinations. A connection check will be added when the transfer engine is integrated.",
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=(FONT, 8),
        ).pack(anchor="w", pady=(4, 12))

        grid = tk.Frame(destination_card, bg=COLORS["panel"])
        grid.pack(fill="x")
        destination_items = list(MANUAL_DESTINATIONS.items())
        for index, (name, path) in enumerate(destination_items):
            r, c = divmod(index, 2)
            tile = tk.Frame(
                grid,
                bg=COLORS["panel_alt"],
                highlightbackground=COLORS["border"],
                highlightthickness=1,
                padx=12,
                pady=10,
            )
            tile.grid(row=r, column=c, sticky="nsew", padx=(0, 8) if c == 0 else (8, 0), pady=5)
            grid.grid_columnconfigure(c, weight=1)
            check = tk.Checkbutton(
                tile,
                text=name,
                variable=self.destination_vars[name],
                bg=COLORS["panel_alt"],
                fg=COLORS["text"],
                activebackground=COLORS["panel_alt"],
                activeforeground=COLORS["accent"],
                selectcolor=COLORS["panel"],
                font=(FONT, 9, "bold"),
                anchor="w",
                cursor="hand2",
            )
            check.pack(anchor="w")
            tk.Label(
                tile,
                text=str(path),
                bg=COLORS["panel_alt"],
                fg=COLORS["muted"],
                font=(MONO, 7),
                wraplength=430,
                justify="left",
            ).pack(anchor="w", padx=(25, 0), pady=(3, 0))
            tk.Label(
                tile,
                text="Connection: Not checked",
                bg=COLORS["panel_alt"],
                fg=COLORS["subtle"],
                font=(FONT, 7),
            ).pack(anchor="w", padx=(25, 0), pady=(5, 0))

        review_row = tk.Frame(self.content, bg=COLORS["bg"])
        review_row.pack(fill="x", pady=(4, 0))
        self._action_button(review_row, "REVIEW SELECTED BACKUP  →", self._show_manual_review, True).pack(side="left")
        tk.Label(
            review_row,
            text="Review opens first. No backup starts from this prototype.",
            bg=COLORS["bg"],
            fg=COLORS["subtle"],
            font=(FONT, 8),
        ).pack(side="left", padx=13)

    def _browse_source(self) -> None:
        selected = filedialog.askdirectory(title="Select Source Folder", mustexist=True)
        if selected:
            self.selected_source.set(selected)

    def _selected_destinations(self) -> list[tuple[str, Path]]:
        return [
            (name, path)
            for name, path in MANUAL_DESTINATIONS.items()
            if self.destination_vars[name].get()
        ]

    def _show_manual_review(self) -> None:
        source = self.selected_source.get().strip()
        destinations = self._selected_destinations()

        if not source:
            messagebox.showinfo("Source Required", "Choose a source folder before opening the review window.")
            return
        if not Path(source).is_dir():
            messagebox.showwarning("Source Not Available", "The selected source folder is not currently available.")
            return
        if not destinations:
            messagebox.showinfo("Destination Required", "Select at least one backup destination.")
            return

        self._open_review_window(
            mode="Manual Archive Backup",
            sources=[("Selected folder", Path(source))],
            destinations=destinations,
        )

    def _show_daily_review(self) -> None:
        destinations = [(name, path) for name, path in DAILY_DESTINATIONS.items()]
        self._open_review_window(
            mode="Daily Smart Backup",
            sources=[("Documents", DAILY_SOURCES[0]), ("Downloads", DAILY_SOURCES[1])],
            destinations=destinations,
        )

    def _open_review_window(self, mode: str, sources: list[tuple[str, Path]], destinations: list[tuple[str, Path]]) -> None:
        window = tk.Toplevel(self.root)
        window.title(f"SmartBackup | {mode} Review")
        window.geometry("850x680")
        window.minsize(720, 560)
        window.configure(bg=COLORS["bg"])
        window.transient(self.root)
        window.grab_set()

        outer = tk.Frame(window, bg=COLORS["bg"], padx=25, pady=22)
        outer.pack(fill="both", expand=True)

        tk.Label(outer, text="REVIEW BEFORE BACKUP", bg=COLORS["bg"], fg=COLORS["accent"], font=(FONT, 8, "bold")).pack(anchor="w")
        tk.Label(outer, text=mode, bg=COLORS["bg"], fg=COLORS["text"], font=(FONT, 19, "bold")).pack(anchor="w", pady=(5, 4))
        tk.Label(
            outer,
            text="Confirm the source and selected destinations before the backup engine runs.",
            bg=COLORS["bg"],
            fg=COLORS["muted"],
            font=(FONT, 9),
        ).pack(anchor="w", pady=(0, 16))

        source_card = self._card(outer, 15)
        source_card.pack(fill="x", pady=(0, 12))
        tk.Label(source_card, text="SOURCE", bg=COLORS["panel"], fg=COLORS["blue"], font=(FONT, 8, "bold")).pack(anchor="w", pady=(0, 7))
        for label, path in sources:
            tk.Label(source_card, text=label, bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 9, "bold")).pack(anchor="w")
            tk.Label(source_card, text=str(path), bg=COLORS["panel"], fg=COLORS["muted"], font=(MONO, 8), wraplength=760, justify="left").pack(anchor="w", pady=(2, 8))

        dest_card = self._card(outer, 15)
        dest_card.pack(fill="both", expand=True, pady=(0, 12))
        tk.Label(dest_card, text="SELECTED DESTINATIONS", bg=COLORS["panel"], fg=COLORS["accent"], font=(FONT, 8, "bold")).pack(anchor="w", pady=(0, 8))
        for label, path in destinations:
            row = tk.Frame(dest_card, bg=COLORS["panel"])
            row.pack(fill="x", pady=4)
            tk.Label(row, text="●", bg=COLORS["panel"], fg=COLORS["accent"], font=(FONT, 9)).pack(side="left")
            name_frame = tk.Frame(row, bg=COLORS["panel"])
            name_frame.pack(side="left", fill="x", expand=True, padx=(9, 8))
            tk.Label(name_frame, text=label, bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 9, "bold")).pack(anchor="w")
            tk.Label(name_frame, text=str(path), bg=COLORS["panel"], fg=COLORS["muted"], font=(MONO, 7), wraplength=680, justify="left").pack(anchor="w", pady=(2, 0))
            tk.Label(row, text="NOT CHECKED", bg=COLORS["panel_alt"], fg=COLORS["amber"], padx=8, pady=4, font=(FONT, 7, "bold")).pack(side="right")

        item_card = self._card(outer, 15)
        item_card.pack(fill="x", pady=(0, 12))
        tk.Label(
            item_card,
            text="ITEM REVIEW",
            bg=COLORS["panel"],
            fg=COLORS["text"],
            font=(FONT, 8, "bold"),
        ).pack(anchor="w")
        placeholder_text = (
            "The scanned file and folder list will appear here when the backup engine is connected."
            if mode == "Daily Smart Backup"
            else "The selected folder contents, file count, total size, and scan results will appear here."
        )
        tk.Label(
            item_card,
            text=placeholder_text,
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=(FONT, 8),
            wraplength=760,
            justify="left",
        ).pack(anchor="w", pady=(7, 0))

        notice = tk.Frame(outer, bg=COLORS["amber_dark"], padx=12, pady=10)
        notice.pack(fill="x", pady=(0, 13))
        tk.Label(
            notice,
            text="Design preview only. No files are scanned, copied, uploaded, overwritten, or deleted.",
            bg=COLORS["amber_dark"],
            fg=COLORS["amber"],
            font=(FONT, 8, "bold"),
            wraplength=760,
            justify="left",
        ).pack(anchor="w")

        controls = tk.Frame(outer, bg=COLORS["bg"])
        controls.pack(fill="x")
        confirm_label = "BACKUP ALL 3" if mode == "Daily Smart Backup" else "START SELECTED BACKUP"
        self._action_button(controls, "CANCEL", window.destroy, False).pack(side="right")
        self._action_button(
            controls,
            confirm_label,
            lambda: self._open_progress_preview(window),
            True,
        ).pack(side="right", padx=(0, 9))

    def _open_progress_preview(self, parent: tk.Toplevel) -> None:
        window = tk.Toplevel(self.root)
        window.title("SmartBackup | Transfer Progress Preview")
        window.geometry("850x650")
        window.minsize(720, 560)
        window.configure(bg=COLORS["bg"])
        window.transient(parent)
        window.grab_set()

        body = tk.Frame(window, bg=COLORS["bg"], padx=25, pady=22)
        body.pack(fill="both", expand=True)
        tk.Label(body, text="TRANSFER MONITOR", bg=COLORS["bg"], fg=COLORS["accent"], font=(FONT, 8, "bold")).pack(anchor="w")
        tk.Label(body, text="Backup Progress", bg=COLORS["bg"], fg=COLORS["text"], font=(FONT, 20, "bold")).pack(anchor="w", pady=(5, 3))
        tk.Label(body, text="A live view of file activity, destination results, and verification.", bg=COLORS["bg"], fg=COLORS["muted"], font=(FONT, 9)).pack(anchor="w", pady=(0, 17))

        summary = tk.Frame(body, bg=COLORS["bg"])
        summary.pack(fill="x", pady=(0, 14))
        for value, label, accent in [
            ("0%", "Overall progress", COLORS["accent"]),
            ("0 / 0", "Files completed", COLORS["blue"]),
            ("—", "Estimated remaining", COLORS["amber"]),
        ]:
            card = self._card(summary, 14)
            card.pack(side="left", fill="both", expand=True, padx=(0, 9))
            tk.Label(card, text=value, bg=COLORS["panel"], fg=accent, font=(FONT, 20, "bold")).pack(anchor="w")
            tk.Label(card, text=label, bg=COLORS["panel"], fg=COLORS["muted"], font=(FONT, 8)).pack(anchor="w", pady=(3, 0))

        progress_card = self._card(body, 16)
        progress_card.pack(fill="x", pady=(0, 13))
        row = tk.Frame(progress_card, bg=COLORS["panel"])
        row.pack(fill="x")
        tk.Label(row, text="TRANSFER PROGRESS", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 9, "bold")).pack(side="left")
        tk.Label(row, text="0%", bg=COLORS["panel"], fg=COLORS["accent"], font=(FONT, 10, "bold")).pack(side="right")
        ttk.Progressbar(progress_card, maximum=100, value=0, style="Smart.Horizontal.TProgressbar").pack(fill="x", pady=(12, 8))
        tk.Label(progress_card, text="0 B transferred  ·  0 B remaining  ·  Speed: —", bg=COLORS["panel"], fg=COLORS["muted"], font=(FONT, 8)).pack(anchor="w")

        table_card = self._card(body, 12)
        table_card.pack(fill="both", expand=True, pady=(0, 13))
        tk.Label(table_card, text="FILE-BY-FILE ACTIVITY", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 9, "bold")).pack(anchor="w", pady=(0, 9))
        tree = ttk.Treeview(table_card, columns=("file", "destination", "status"), show="headings", style="Smart.Treeview", height=5)
        tree.heading("file", text="FILE")
        tree.heading("destination", text="DESTINATION")
        tree.heading("status", text="STATUS")
        tree.column("file", width=270, anchor="w")
        tree.column("destination", width=230, anchor="w")
        tree.column("status", width=150, anchor="center")
        tree.pack(fill="both", expand=True)
        tree.insert("", "end", values=("Waiting for transfer engine", "—", "NOT STARTED"))

        tk.Label(
            body,
            text="Design preview only — progress values are placeholders and no transfer is running.",
            bg=COLORS["bg"],
            fg=COLORS["amber"],
            font=(FONT, 8, "bold"),
        ).pack(anchor="w", pady=(0, 10))
        self._action_button(body, "CLOSE", window.destroy, False).pack(anchor="e")

    def _build_activity_page(self) -> None:
        assert self.content is not None
        summary = self._card(self.content, 20)
        summary.pack(fill="x", pady=(0, 14))
        tk.Label(summary, text="BACKUP HISTORY", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 13, "bold")).pack(anchor="w")
        tk.Label(
            summary,
            text="The completed application will record each backup run, selected destinations, file-level outcomes, failed items, retry attempts, and checksum verification results.",
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=(FONT, 9),
            wraplength=900,
            justify="left",
        ).pack(anchor="w", pady=(6, 0))

        table = self._card(self.content, 14)
        table.pack(fill="both", expand=True)
        columns = ("date", "mode", "destination", "result")
        tree = ttk.Treeview(table, columns=columns, show="headings", style="Smart.Treeview", height=8)
        headings = {
            "date": ("DATE / TIME", 170),
            "mode": ("BACKUP MODE", 190),
            "destination": ("DESTINATION", 270),
            "result": ("RESULT", 170),
        }
        for key, (label, width) in headings.items():
            tree.heading(key, text=label)
            tree.column(key, width=width, anchor="w")
        tree.pack(fill="both", expand=True)
        tree.insert("", "end", values=("—", "No recorded runs", "—", "Awaiting engine integration"))
        tk.Label(table, text="No real backup history is connected in this UI prototype.", bg=COLORS["panel"], fg=COLORS["subtle"], font=(FONT, 8)).pack(anchor="w", pady=(10, 0))


def main() -> None:
    root = tk.Tk()
    SmartBackupDashboard(root)
    root.mainloop()


if __name__ == "__main__":
    main()
