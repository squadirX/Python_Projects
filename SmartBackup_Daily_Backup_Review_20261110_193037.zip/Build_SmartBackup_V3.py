
from pathlib import Path
import ast

PROJECT = Path(__file__).resolve().parent
SOURCE = PROJECT / "SmartBackup_Dashboard_Prototype_v2.py"
OUTPUT = PROJECT / "SmartBackup_Dashboard_Prototype_v3.py"

if not SOURCE.is_file():
    raise FileNotFoundError(f"V2 source not found: {SOURCE}")

if OUTPUT.exists():
    raise FileExistsError(
        f"V3 already exists. Refusing to overwrite: {OUTPUT}"
    )

code = SOURCE.read_text(encoding="utf-8")


def replace_once(old, new, label):
    global code
    count = code.count(old)
    if count != 1:
        raise RuntimeError(
            f"Patch failed: {label}. Expected 1 match, found {count}"
        )
    code = code.replace(old, new, 1)


# 1. Add Windows C drive
replace_once(
    '    "Windows D: ADATA": Path("/Volumes/Windows_D_ADATA/DATA/SmartBackup_Archives"),\n',
    '    "Windows C: Drive": Path("/Volumes/Windows_C_Drive/SmartBackup_Archives"),\n'
    '    "Windows D: ADATA": Path("/Volumes/Windows_D_ADATA/DATA/SmartBackup_Archives"),\n',
    "Windows C destination"
)

replace_once(
    'WINDOWS_MOUNTS = {\n'
    '    "Windows D: ADATA": Path("/Volumes/Windows_D_ADATA"),\n',
    'WINDOWS_MOUNTS = {\n'
    '    "Windows C: Drive": Path("/Volumes/Windows_C_Drive"),\n'
    '    "Windows D: ADATA": Path("/Volumes/Windows_D_ADATA"),\n',
    "Windows C mount"
)


# 2. Update destination overview
replace_once(
    '            ("Windows D: ADATA", COLORS["blue"]),\n',
    '            ("Windows C: Drive", COLORS["accent"]),\n'
    '            ("Windows D: ADATA", COLORS["blue"]),\n',
    "destination overview C drive"
)

replace_once(
    '"07", "Manual destinations",',
    '"08", "Manual destinations",',
    "destination count"
)

replace_once(
    'Local, iCloud, OneDrive, Google Drive, Dropbox, D: and F:',
    'Local, iCloud, OneDrive, Google Drive, Dropbox, C:, D: and F:',
    "destination summary"
)

replace_once(
    'WINDOWS D:   ·   WINDOWS F:',
    'WINDOWS C:   ·   WINDOWS D:   ·   WINDOWS F:',
    "manual destination labels"
)


# 3. White buttons with black text and consistent sizing
start = code.index("    def _action_button(")
end = code.index("    def _build_overview(", start)

button_method = '''    def _action_button(self, parent: tk.Widget, text: str, command,
                       primary: bool = True, width: int | None = None) -> tk.Button:
        normal_bg = "#FFFFFF" if primary else "#EEF2F7"
        hover_bg = "#E5EDF7"
        button = tk.Button(
            parent,
            text=text,
            command=command,
            bg=normal_bg,
            fg="#111827",
            activebackground=hover_bg,
            activeforeground="#111827",
            relief="raised",
            overrelief="groove",
            bd=2,
            highlightthickness=1,
            highlightbackground=COLORS["border"],
            padx=18,
            pady=9,
            font=(FONT, 12, "bold"),
            cursor="hand2",
            width=width,
            height=2,
            justify="center",
            anchor="center",
        )
        button.bind("<Enter>", lambda event: button.configure(bg=hover_bg))
        button.bind("<Leave>", lambda event: button.configure(bg=normal_bg))
        return button

'''
code = code[:start] + button_method + code[end:]


# 4. Workspace navigation buttons: white background, black text
replace_once(
    '                padx=16,\n'
    '                pady=17,\n'
    '                bg=COLORS["sidebar"],\n'
    '                fg=COLORS["muted"],\n'
    '                activebackground=COLORS["panel_hover"],\n'
    '                activeforeground=COLORS["text"],\n',
    '                padx=16,\n'
    '                pady=12,\n'
    '                bg="#FFFFFF",\n'
    '                fg="#111827",\n'
    '                activebackground="#E5EDF7",\n'
    '                activeforeground="#111827",\n',
    "workspace navigation buttons"
)

replace_once(
    '                bg=COLORS["panel_hover"] if active else COLORS["sidebar"],\n'
    '                fg=COLORS["accent"] if active else COLORS["muted"],\n',
    '                bg="#DCEBFA" if active else "#FFFFFF",\n'
    '                fg="#111827",\n',
    "navigation active colors"
)


# 5. Create a separate scroll area and fixed footer
old_shell = '''        body = tk.Frame(main, bg=COLORS["bg"])
        body.pack(fill="both", expand=True, padx=28, pady=(14, 18))

        self.canvas = tk.Canvas(
            body,
            bg=COLORS["bg"],
            highlightthickness=0,
            borderwidth=0,
        )
        self.scrollbar = ttk.Scrollbar(
            body,
            orient="vertical",
            command=self.canvas.yview,
        )
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

        self.content = tk.Frame(self.canvas, bg=COLORS["bg"])
        self.content_window = self.canvas.create_window(
            (0, 0), window=self.content, anchor="nw"
        )
        self.content.bind("<Configure>", self._update_scroll_region)
        self.canvas.bind("<Configure>", self._resize_content)
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)
'''

new_shell = '''        body = tk.Frame(main, bg=COLORS["bg"])
        body.pack(fill="both", expand=True, padx=28, pady=(14, 18))

        scroll_area = tk.Frame(body, bg=COLORS["bg"])
        scroll_area.pack(fill="both", expand=True)

        self.canvas = tk.Canvas(
            scroll_area,
            bg=COLORS["bg"],
            highlightthickness=0,
            borderwidth=0,
        )
        self.scrollbar = ttk.Scrollbar(
            scroll_area,
            orient="vertical",
            command=self.canvas.yview,
        )
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

        self.content = tk.Frame(self.canvas, bg=COLORS["bg"])
        self.content_window = self.canvas.create_window(
            (0, 0), window=self.content, anchor="nw"
        )
        self.content.bind("<Configure>", self._update_scroll_region)
        self.canvas.bind("<Configure>", self._resize_content)
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)

        self.manual_footer = tk.Frame(
            body,
            bg=COLORS["panel"],
            highlightbackground=COLORS["border"],
            highlightthickness=1,
            padx=12,
            pady=9,
        )
        self._action_button(
            self.manual_footer,
            "REVIEW SELECTED BACKUP  →",
            self._show_manual_review,
            True,
        ).pack(side="left")
        tk.Label(
            self.manual_footer,
            text="Review first. No files are transferred by this prototype.",
            bg=COLORS["panel"],
            fg=COLORS["text"],
            font=(FONT, 10),
        ).pack(side="left", padx=12)
        self.manual_footer.pack_forget()
'''

replace_once(old_shell, new_shell, "fixed manual footer")


# 6. Show footer only on Manual Archive page
replace_once(
    '        self.current_page = page\n'
    '        self._clear_content()\n',
    '        self.current_page = page\n'
    '        if page == "manual":\n'
    '            self.manual_footer.pack(side="bottom", fill="x", pady=(8, 0))\n'
    '        else:\n'
    '            self.manual_footer.pack_forget()\n'
    '        self._clear_content()\n',
    "manual footer visibility"
)


# 7. Compact destination cards
replace_once(
    '            tile = tk.Frame(grid, bg=COLORS["panel_alt"], highlightbackground=COLORS["border"], highlightthickness=1, padx=16, pady=14)\n'
    '            tile.grid(row=row, column=col, sticky="nsew", padx=(0, 9) if col == 0 else (9, 0), pady=6)\n',
    '            tile = tk.Frame(grid, bg=COLORS["panel_alt"], highlightbackground=COLORS["border"], highlightthickness=1, padx=11, pady=8)\n'
    '            tile.grid(row=row, column=col, sticky="nsew", padx=(0, 7) if col == 0 else (7, 0), pady=4)\n',
    "compact destination tiles"
)

replace_once(
    'font=(MONO, 9), wraplength=440, justify="left"',
    'font=(MONO, 8), wraplength=400, justify="left"',
    "compact destination paths"
)

replace_once(
    'font=(FONT, 10, "bold"), wraplength=440, justify="left"',
    'font=(FONT, 9, "bold"), wraplength=400, justify="left"',
    "compact destination status"
)


# 8. Remove the old scrolling review button row
review_start = code.index(
    '        review_row = tk.Frame(self.content, bg=COLORS["bg"])'
)
review_end = code.index(
    '    def _refresh_manual_status(self)',
    review_start
)
code = code[:review_start] + code[review_end:]


# 9. Update path-check explanation
replace_once(
    'Read-only check only. Cloud sync and write permission are not verified.',
    'Checks folder visibility only. Cloud sync and write permission are not verified.',
    "path check explanation"
)


# 10. Validate before saving
ast.parse(code, filename=str(OUTPUT))

OUTPUT.write_text(code, encoding="utf-8")

saved_code = OUTPUT.read_text(encoding="utf-8")
ast.parse(saved_code, filename=str(OUTPUT))

print("V3 BUILD SUCCESSFUL")
print(f"Created: {OUTPUT}")
print(f"File size: {OUTPUT.stat().st_size:,} bytes")
print("V2 remains unchanged.")
print("Python syntax check: PASSED")
print("Backup engine: NOT CONNECTED - UI PROTOTYPE ONLY")
