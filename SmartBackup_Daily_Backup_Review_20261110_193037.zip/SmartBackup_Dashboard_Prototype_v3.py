from __future__ import annotations

import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from pathlib import Path


APP_TITLE = "SmartBackup"
DEVELOPER = "Developed by Saiful Quadir"

COLORS = {
    "bg": "#0B1220",
    "sidebar": "#0E1728",
    "panel": "#121F33",
    "panel_alt": "#17263D",
    "panel_hover": "#1B2D47",
    "border": "#405875",
    "text": "#EDF3FA",
    "muted": "#C6D1DF",
    "subtle": "#AAB9CB",
    "accent": "#39D6B4",
    "accent_dark": "#153F3B",
    "blue": "#75B7FF",
    "blue_dark": "#1B3553",
    "amber": "#F1C56B",
    "amber_dark": "#49391D",
    "red": "#FF7C88",
    "red_dark": "#48232D",
    "white": "#FFFFFF",
    "button_primary": "#9BE8D3",
    "button_primary_hover": "#BDF3E5",
    "button_secondary": "#DCEBFA",
    "button_secondary_hover": "#EEF6FF",
    "button_text": "#173047",
    "nav_active": "#25445F",
}

FONT = "Helvetica Neue"
MONO = "Menlo"

HOME = Path.home()
CLOUD_STORAGE = HOME / "Library" / "CloudStorage"
DAILY_SOURCES = [HOME / "Documents", HOME / "Downloads"]
ICLOUD_ROOT = HOME / "Library/Mobile Documents/com~apple~CloudDocs"
ONEDRIVE_ROOT = CLOUD_STORAGE / "OneDrive-Personal(2) 2"


def discover_cloud_folder(prefixes: tuple[str, ...], fallback_names: tuple[str, ...] = ()) -> Path | None:
    """Find an existing local cloud-sync folder without changing it."""
    if CLOUD_STORAGE.is_dir():
        try:
            for candidate in sorted(CLOUD_STORAGE.iterdir(), key=lambda item: item.name.lower()):
                if candidate.is_dir() and any(candidate.name.lower().startswith(prefix.lower()) for prefix in prefixes):
                    return candidate
        except OSError:
            pass
    for name in fallback_names:
        candidate = HOME / name
        if candidate.is_dir():
            return candidate
    return None


GOOGLE_DRIVE_ROOT = discover_cloud_folder(("GoogleDrive-", "Google Drive"), ("Google Drive", "My Drive"))
DROPBOX_ROOT = discover_cloud_folder(("Dropbox",), ("Dropbox",))
GOOGLE_DRIVE_BASE = (
    GOOGLE_DRIVE_ROOT / "My Drive"
    if GOOGLE_DRIVE_ROOT and (GOOGLE_DRIVE_ROOT / "My Drive").is_dir()
    else GOOGLE_DRIVE_ROOT
)

DAILY_DESTINATIONS = {
    "Local": HOME / "Documents",
    "iCloud Drive": ICLOUD_ROOT / "SmartBackup",
    "OneDrive": ONEDRIVE_ROOT / "SmartBackup",
}

MANUAL_DESTINATIONS: dict[str, Path | None] = {
    "OneDrive": ONEDRIVE_ROOT / "SmartBackup" / "Archives",
    "iCloud Drive": ICLOUD_ROOT / "SmartBackup" / "Archives",
    "Google Drive": GOOGLE_DRIVE_BASE / "SmartBackup" / "Archives" if GOOGLE_DRIVE_BASE else None,
    "Dropbox": DROPBOX_ROOT / "SmartBackup" / "Archives" if DROPBOX_ROOT else None,
    "Windows D: ADATA": Path("/Volumes/Windows_D_ADATA/DATA/SmartBackup_Archives"),
    "Windows F: Transcend": Path("/Volumes/Windows_F_TRANSCEND/SmartBackup_Archives"),
    "Local Mac": HOME / "Documents/SmartBackup/Archives",
}

WINDOWS_MOUNTS = {
    "Windows D: ADATA": Path("/Volumes/Windows_D_ADATA"),
    "Windows F: Transcend": Path("/Volumes/Windows_F_TRANSCEND"),
}



class SmartBackupDashboard:
    """UI-only prototype. No backup, sync, delete, or network operations are connected."""

    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title(f"{APP_TITLE} | Backup Command Center")
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        window_width = min(1420, max(1080, screen_width - 60))
        window_height = min(900, max(700, screen_height - 100))
        self.root.geometry(f"{window_width}x{window_height}")
        self.root.minsize(1040, 680)
        self.root.configure(bg=COLORS["bg"])

        self.selected_source = tk.StringVar(value="")
        self.destination_vars = {
            name: tk.BooleanVar(value=(name == "OneDrive"))
            for name in MANUAL_DESTINATIONS
        }
        self.current_page = "overview"
        self.content: tk.Frame | None = None
        self.nav_buttons: dict[str, tk.Button] = {}

        self._configure_ttk()
        self._build_shell()
        self.show_page("overview")

    def _configure_ttk(self) -> None:
        style = ttk.Style(self.root)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(
            "Smart.Horizontal.TProgressbar",
            troughcolor=COLORS["panel_alt"],
            background=COLORS["accent"],
            bordercolor=COLORS["panel_alt"],
            lightcolor=COLORS["accent"],
            darkcolor=COLORS["accent"],
            thickness=12,
        )
        style.configure(
            "Smart.Treeview",
            background=COLORS["panel"],
            fieldbackground=COLORS["panel"],
            foreground=COLORS["text"],
            bordercolor=COLORS["border"],
            rowheight=44,
            font=(FONT, 13),
        )
        style.configure(
            "Smart.Treeview.Heading",
            background=COLORS["panel_alt"],
            foreground=COLORS["muted"],
            relief="flat",
            font=(FONT, 18, "bold"),
        )
        style.configure(
            "Vertical.TScrollbar",
            background=COLORS["panel_alt"],
            troughcolor=COLORS["bg"],
            bordercolor=COLORS["bg"],
            arrowcolor=COLORS["muted"],
            darkcolor=COLORS["panel_alt"],
            lightcolor=COLORS["panel_alt"],
            relief="flat",
            width=10,
        )
        style.map(
            "Vertical.TScrollbar",
            background=[("active", COLORS["accent"])],
        )
        style.map(
            "Smart.Treeview",
            background=[("selected", COLORS["blue_dark"])],
            foreground=[("selected", COLORS["white"])],
        )

    def _build_shell(self) -> None:
        shell = tk.Frame(self.root, bg=COLORS["bg"])
        shell.pack(fill="both", expand=True)

        self.sidebar = tk.Frame(shell, bg=COLORS["sidebar"], width=278)
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        main = tk.Frame(shell, bg=COLORS["bg"])
        main.pack(side="right", fill="both", expand=True)

        self._build_sidebar()
        self._build_topbar(main)

        body = tk.Frame(main, bg=COLORS["bg"])
        body.pack(fill="both", expand=True, padx=28, pady=(14, 18))

        self.canvas = tk.Canvas(
            body,
            bg=COLORS["bg"],
            highlightthickness=0,
            borderwidth=0,
        )
        self.scrollbar = ttk.Scrollbar(
            body,
            orient="vertical",
            command=self.canvas.yview,
        )
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")

        self.content = tk.Frame(self.canvas, bg=COLORS["bg"])
        self.content_window = self.canvas.create_window(
            (0, 0), window=self.content, anchor="nw"
        )
        self.content.bind("<Configure>", self._update_scroll_region)
        self.canvas.bind("<Configure>", self._resize_content)
        self.canvas.bind_all("<MouseWheel>", self._on_mousewheel)

        self.manual_footer = tk.Frame(
            body,
            bg=COLORS["panel"],
            highlightbackground=COLORS["border"],
            highlightthickness=1,
            padx=14,
            pady=10,
        )
        self._action_button(
            self.manual_footer,
            "REVIEW SELECTED BACKUP  →",
            self._show_manual_review,
            True,
        ).pack(side="left")
        tk.Label(
            self.manual_footer,
            text="Review opens first. No backup starts from this prototype.",
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=(FONT, 10),
        ).pack(side="left", padx=12)
        self.manual_footer.pack_forget()

    def _update_scroll_region(self, _event=None) -> None:
        if hasattr(self, "canvas") and hasattr(self, "content"):
            self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _resize_content(self, event) -> None:
        if hasattr(self, "content_window"):
            self.canvas.itemconfigure(self.content_window, width=event.width)

    def _on_mousewheel(self, event) -> None:
        if hasattr(self, "canvas"):
            self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def _build_sidebar(self) -> None:
        brand = tk.Frame(self.sidebar, bg=COLORS["sidebar"])
        brand.pack(fill="x", padx=22, pady=(28, 34))

        mark = tk.Label(
            brand,
            text="S",
            bg=COLORS["accent_dark"],
            fg=COLORS["accent"],
            font=(FONT, 25, "bold"),
            width=2,
            height=1,
            padx=5,
            pady=5,
        )
        mark.pack(side="left")

        brand_text = tk.Frame(brand, bg=COLORS["sidebar"])
        brand_text.pack(side="left", padx=(11, 0))
        tk.Label(
            brand_text,
            text="SmartBackup",
            bg=COLORS["sidebar"],
            fg=COLORS["text"],
            font=(FONT, 17, "bold"),
        ).pack(anchor="w")
        tk.Label(
            brand_text,
            text="BACKUP COMMAND CENTER",
            bg=COLORS["sidebar"],
            fg=COLORS["subtle"],
            font=(FONT, 13, "bold"),
        ).pack(anchor="w", pady=(3, 0))

        tk.Label(
            self.sidebar,
            text="WORKSPACE",
            bg=COLORS["sidebar"],
            fg=COLORS["subtle"],
            font=(FONT, 11, "bold"),
        ).pack(anchor="w", padx=23, pady=(0, 9))

        navigation = [
            ("overview", "◈", "Overview"),
            ("daily", "◷", "Daily Backup"),
            ("manual", "▣", "Manual Archive"),
            ("activity", "≋", "Activity & Reports"),
        ]
        for key, symbol, label in navigation:
            button = tk.Button(
                self.sidebar,
                text=f"  {symbol}    {label}",
                command=lambda page=key: self.show_page(page),
                anchor="w",
                relief="flat",
                bd=0,
                highlightthickness=0,
                padx=16,
                pady=12,
                bg=COLORS["sidebar"],
                fg=COLORS["text"],
                activebackground=COLORS["panel_hover"],
                activeforeground=COLORS["text"],
                font=(FONT, 13, "bold"),
                cursor="hand2",
            )
            button.pack(fill="x", padx=12, pady=2)
            self.nav_buttons[key] = button

        spacer = tk.Frame(self.sidebar, bg=COLORS["sidebar"])
        spacer.pack(fill="both", expand=True)

        status_card = tk.Frame(
            self.sidebar,
            bg=COLORS["panel"],
            highlightbackground=COLORS["border"],
            highlightthickness=1,
        )
        status_card.pack(fill="x", padx=15, pady=(0, 17))
        tk.Label(
            status_card,
            text="SYSTEM MODE",
            bg=COLORS["panel"],
            fg=COLORS["subtle"],
            font=(FONT, 11, "bold"),
        ).pack(anchor="w", padx=13, pady=(12, 5))
        tk.Label(
            status_card,
            text="UI Design Preview",
            bg=COLORS["panel"],
            fg=COLORS["accent"],
            font=(FONT, 13, "bold"),
        ).pack(anchor="w", padx=13)
        tk.Label(
            status_card,
            text="No files will be transferred",
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=(FONT, 11),
        ).pack(anchor="w", padx=13, pady=(3, 12))

        tk.Label(
            self.sidebar,
            text=DEVELOPER,
            bg=COLORS["sidebar"],
            fg=COLORS["subtle"],
            font=(FONT, 11),
        ).pack(anchor="w", padx=21, pady=(0, 17))

    def _build_topbar(self, parent: tk.Frame) -> None:
        top = tk.Frame(parent, bg=COLORS["bg"], height=74)
        top.pack(fill="x", padx=28, pady=(20, 0))
        top.pack_propagate(False)

        left = tk.Frame(top, bg=COLORS["bg"])
        left.pack(side="left", fill="y")
        self.page_title = tk.Label(
            left,
            text="Overview",
            bg=COLORS["bg"],
            fg=COLORS["text"],
            font=(FONT, 25, "bold"),
        )
        self.page_title.pack(anchor="w")
        self.page_subtitle = tk.Label(
            left,
            text="A clear view of your backup workflow and destinations.",
            bg=COLORS["bg"],
            fg=COLORS["muted"],
            font=(FONT, 12),
        )
        self.page_subtitle.pack(anchor="w", pady=(4, 0))

        pill = tk.Label(
            top,
            text="UI PREVIEW  |  TRANSFER ENGINE NOT CONNECTED",
            bg=COLORS["amber_dark"],
            fg=COLORS["amber"],
            padx=12,
            pady=8,
            font=(FONT, 11, "bold"),
        )
        pill.pack(side="right", anchor="center", pady=8)

    def _clear_content(self) -> None:
        if self.content is not None:
            for widget in self.content.winfo_children():
                widget.destroy()

    def show_page(self, page: str) -> None:
        self.current_page = page
        if page == "manual":
            self.manual_footer.pack(side="bottom", fill="x", pady=(8, 0))
        else:
            self.manual_footer.pack_forget()
        self._clear_content()

        for key, button in self.nav_buttons.items():
            active = key == page
            button.configure(
                bg=COLORS["nav_active"] if active else COLORS["sidebar"],
                fg=COLORS["button_primary"] if active else COLORS["text"],
            )

        page_info = {
            "overview": ("Overview", "A clear view of your backup workflow and destinations."),
            "daily": ("Daily Backup", "Keep the existing automatic Documents and Downloads workflow."),
            "manual": ("Manual Archive", "Choose a folder, select destinations, review, and then back up."),
            "activity": ("Activity & Reports", "A single place for transfer history, results, and verification reports."),
        }
        title, subtitle = page_info[page]
        self.page_title.configure(text=title)
        self.page_subtitle.configure(text=subtitle)

        if page == "overview":
            self._build_overview()
        elif page == "daily":
            self._build_daily_page()
        elif page == "manual":
            self._build_manual_page()
        else:
            self._build_activity_page()

    def _card(self, parent: tk.Widget, padding: int = 17) -> tk.Frame:
        frame = tk.Frame(
            parent,
            bg=COLORS["panel"],
            highlightbackground=COLORS["border"],
            highlightthickness=1,
            padx=padding,
            pady=padding,
        )
        return frame

    def _section_heading(self, parent: tk.Widget, title: str, subtitle: str | None = None) -> None:
        wrapper = tk.Frame(parent, bg=COLORS["bg"])
        wrapper.pack(fill="x", pady=(0, 12))
        tk.Label(
            wrapper,
            text=title,
            bg=COLORS["bg"],
            fg=COLORS["text"],
            font=(FONT, 18, "bold"),
        ).pack(anchor="w")
        if subtitle:
            tk.Label(
                wrapper,
                text=subtitle,
                bg=COLORS["bg"],
                fg=COLORS["muted"],
                font=(FONT, 12),
            ).pack(anchor="w", pady=(3, 0))

    def _metric_card(self, parent: tk.Widget, value: str, label: str, hint: str, accent: str) -> None:
        card = self._card(parent, 16)
        card.pack(side="left", fill="both", expand=True, padx=(0, 12))
        tk.Label(card, text=value, bg=COLORS["panel"], fg=accent, font=(FONT, 23, "bold")).pack(anchor="w")
        tk.Label(card, text=label, bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 13, "bold")).pack(anchor="w", pady=(4, 0))
        tk.Label(card, text=hint, bg=COLORS["panel"], fg=COLORS["muted"], font=(FONT, 11)).pack(anchor="w", pady=(5, 0))

    def _action_button(self, parent: tk.Widget, text: str, command,
                       primary: bool = True, width: int | None = None) -> tk.Button:
        normal_bg = COLORS["button_primary"] if primary else COLORS["button_secondary"]
        hover_bg = COLORS["button_primary_hover"] if primary else COLORS["button_secondary_hover"]

        button = tk.Button(
            parent,
            text=text,
            command=command,
            bg=normal_bg,
            fg=COLORS["button_text"],
            activebackground=hover_bg,
            activeforeground=COLORS["button_text"],
            relief="raised",
            overrelief="groove",
            bd=2,
            highlightthickness=1,
            highlightbackground=COLORS["border"],
            highlightcolor=COLORS["border"],
            padx=18,
            pady=9,
            font=(FONT, 12, "bold"),
            cursor="hand2",
            width=width,
            height=2,
            justify="center",
            anchor="center",
        )
        button.bind("<Enter>", lambda event: button.configure(bg=hover_bg))
        button.bind("<Leave>", lambda event: button.configure(bg=normal_bg))
        return button

    def _build_overview(self) -> None:
        assert self.content is not None
        hero = tk.Frame(self.content, bg=COLORS["panel_alt"], padx=24, pady=22)
        hero.pack(fill="x", pady=(0, 17))
        hero_left = tk.Frame(hero, bg=COLORS["panel_alt"])
        hero_left.pack(side="left", fill="both", expand=True)
        tk.Label(
            hero_left,
            text="Your backups. Organized.",
            bg=COLORS["panel_alt"],
            fg=COLORS["text"],
            font=(FONT, 23, "bold"),
        ).pack(anchor="w")
        tk.Label(
            hero_left,
            text="Run your regular daily backup or create a one-time archive to the destination you choose.",
            bg=COLORS["panel_alt"],
            fg=COLORS["muted"],
            font=(FONT, 12),
            wraplength=650,
            justify="left",
        ).pack(anchor="w", pady=(7, 0))
        self._action_button(hero, "OPEN MANUAL ARCHIVE  →", lambda: self.show_page("manual"), True).pack(side="right", padx=(15, 0), pady=10)

        metrics = tk.Frame(self.content, bg=COLORS["bg"])
        metrics.pack(fill="x", pady=(0, 23))
        self._metric_card(metrics, "02", "Backup modes", "Daily Backup + Manual Archive", COLORS["blue"])
        self._metric_card(metrics, "07", "Manual destinations", "Local, iCloud, OneDrive, Google Drive, Dropbox, D: and F:", COLORS["accent"])
        self._metric_card(metrics, "—", "Active transfers", "Transfer engine not connected", COLORS["amber"])

        self._section_heading(self.content, "BACKUP WORKSPACE", "Choose how you want to protect your files.")
        cards = tk.Frame(self.content, bg=COLORS["bg"])
        cards.pack(fill="x", pady=(0, 22))

        daily = self._card(cards, 20)
        daily.pack(side="left", fill="both", expand=True, padx=(0, 9))
        tk.Label(daily, text="◷", bg=COLORS["panel"], fg=COLORS["blue"], font=(FONT, 25, "bold")).pack(anchor="w")
        tk.Label(daily, text="Daily Smart Backup", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 17, "bold")).pack(anchor="w", pady=(8, 5))
        tk.Label(
            daily,
            text="Automatically scan Documents and Downloads for new or modified items. Keep the familiar review and approval process.",
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=(FONT, 12),
            wraplength=390,
            justify="left",
        ).pack(anchor="w", pady=(0, 15))
        tk.Label(daily, text="LOCAL   ·   iCLOUD   ·   ONEDRIVE", bg=COLORS["panel"], fg=COLORS["blue"], font=(FONT, 11, "bold")).pack(anchor="w", pady=(0, 13))
        self._action_button(daily, "OPEN DAILY BACKUP  →", lambda: self.show_page("daily"), False).pack(anchor="w")

        manual = self._card(cards, 20)
        manual.pack(side="left", fill="both", expand=True, padx=(9, 0))
        tk.Label(manual, text="▣", bg=COLORS["panel"], fg=COLORS["accent"], font=(FONT, 25, "bold")).pack(anchor="w")
        tk.Label(manual, text="Manual Archive Backup", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 17, "bold")).pack(anchor="w", pady=(8, 5))
        tk.Label(
            manual,
            text="Browse to any folder, choose one or more destinations, review the selection, and monitor each file in the progress window.",
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=(FONT, 12),
            wraplength=390,
            justify="left",
        ).pack(anchor="w", pady=(0, 15))
        tk.Label(manual, text="ONEDRIVE   ·   ICLOUD   ·   GOOGLE DRIVE   ·   DROPBOX   ·   WINDOWS D:   ·   WINDOWS F:", bg=COLORS["panel"], fg=COLORS["accent"], font=(FONT, 11, "bold")).pack(anchor="w", pady=(0, 13))
        self._action_button(manual, "CREATE MANUAL ARCHIVE  →", lambda: self.show_page("manual"), True).pack(anchor="w")

        self._section_heading(self.content, "DESTINATION OVERVIEW", "Configured locations are shown for design review; live connection checks are not yet wired.")
        self._destination_strip(self.content)

    def _display_path(self, path: Path | None) -> str:
        return str(path) if path else "Sync folder not detected on this Mac"

    def _destination_status(self, name: str) -> str:
        path = MANUAL_DESTINATIONS.get(name)
        if path is None:
            return "SETUP REQUIRED - FOLDER NOT DETECTED"
        if name in WINDOWS_MOUNTS:
            return "NETWORK VOLUME MOUNTED" if WINDOWS_MOUNTS[name].is_mount() else "NETWORK VOLUME NOT MOUNTED"
        if name in {"OneDrive", "iCloud Drive", "Google Drive", "Dropbox"}:
            sync_root = {
                "OneDrive": ONEDRIVE_ROOT,
                "iCloud Drive": ICLOUD_ROOT,
                "Google Drive": GOOGLE_DRIVE_ROOT,
                "Dropbox": DROPBOX_ROOT,
            }.get(name)
            if sync_root and sync_root.is_dir():
                return "LOCAL SYNC FOLDER FOUND - CLOUD SYNC NOT VERIFIED"
            return "SYNC FOLDER NOT DETECTED"
        if path.parent.is_dir():
            return "LOCAL PARENT FOLDER FOUND - WRITE ACCESS NOT TESTED"
        return "LOCAL PARENT FOLDER NOT FOUND"

    def _destination_strip(self, parent: tk.Widget) -> None:
        entries = [
            ("OneDrive", COLORS["accent"]),
            ("iCloud Drive", COLORS["blue"]),
            ("Google Drive", COLORS["blue"]),
            ("Dropbox", COLORS["amber"]),
            ("Windows D: ADATA", COLORS["blue"]),
            ("Windows F: Transcend", COLORS["amber"]),
            ("Local Mac", COLORS["accent"]),
        ]
        grid = tk.Frame(parent, bg=COLORS["bg"])
        grid.pack(fill="x")
        for index, (name, accent) in enumerate(entries):
            row, col = divmod(index, 3)
            card = self._card(grid, 16)
            card.grid(row=row, column=col, sticky="nsew", padx=(0, 9) if col < 2 else (0, 0), pady=6)
            grid.grid_columnconfigure(col, weight=1)
            tk.Label(card, text=name, bg=COLORS["panel"], fg=accent, font=(FONT, 13, "bold")).pack(anchor="w")
            tk.Label(card, text=self._display_path(MANUAL_DESTINATIONS[name]), bg=COLORS["panel"], fg=COLORS["muted"], font=(MONO, 9), wraplength=300, justify="left").pack(anchor="w", pady=(6, 0))
            tk.Label(card, text=self._destination_status(name), bg=COLORS["panel"], fg=COLORS["subtle"], font=(FONT, 10, "bold"), wraplength=300, justify="left").pack(anchor="w", pady=(8, 0))

    def _build_daily_page(self) -> None:
        assert self.content is not None
        banner = self._card(self.content, 20)
        banner.pack(fill="x", pady=(0, 16))
        tk.Label(banner, text="EXISTING WORKFLOW", bg=COLORS["panel"], fg=COLORS["blue"], font=(FONT, 11, "bold")).pack(anchor="w")
        tk.Label(banner, text="Daily Documents & Downloads Backup", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 25, "bold")).pack(anchor="w", pady=(6, 4))
        tk.Label(
            banner,
            text="The existing process remains: scan for today's new or modified items → show the review window → user approval → back up to all three daily destinations.",
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=(FONT, 12),
            wraplength=850,
            justify="left",
        ).pack(anchor="w")

        columns = tk.Frame(self.content, bg=COLORS["bg"])
        columns.pack(fill="x", pady=(0, 16))
        sources = self._card(columns, 18)
        sources.pack(side="left", fill="both", expand=True, padx=(0, 9))
        tk.Label(sources, text="SOURCE FOLDERS", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 13, "bold")).pack(anchor="w", pady=(0, 12))
        for path in DAILY_SOURCES:
            self._path_row(sources, "Folder", path)

        destinations = self._card(columns, 18)
        destinations.pack(side="left", fill="both", expand=True, padx=(9, 0))
        tk.Label(destinations, text="DAILY DESTINATIONS", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 13, "bold")).pack(anchor="w", pady=(0, 12))
        for name, path in DAILY_DESTINATIONS.items():
            self._path_row(destinations, name, path)

        note = tk.Frame(self.content, bg=COLORS["blue_dark"], padx=16, pady=13)
        note.pack(fill="x", pady=(0, 17))
        tk.Label(
            note,
            text="The current scan, manifest rules, date-wise folder structure, and three-destination approval flow will be retained when the engine is connected.",
            bg=COLORS["blue_dark"],
            fg=COLORS["text"],
            font=(FONT, 12),
            wraplength=900,
            justify="left",
        ).pack(anchor="w")

        controls = tk.Frame(self.content, bg=COLORS["bg"])
        controls.pack(fill="x")
        self._action_button(controls, "PREVIEW DAILY REVIEW WINDOW", self._show_daily_review, True).pack(side="left")
        tk.Label(controls, text="Preview only — no scan or backup is started.", bg=COLORS["bg"], fg=COLORS["subtle"], font=(FONT, 11)).pack(side="left", padx=14)

    def _path_row(self, parent: tk.Widget, label: str, path: Path) -> None:
        wrapper = tk.Frame(parent, bg=COLORS["panel"])
        wrapper.pack(fill="x", pady=5)
        tk.Label(wrapper, text=label, bg=COLORS["panel"], fg=COLORS["accent"], font=(FONT, 11, "bold"), width=15, anchor="w").pack(anchor="w")
        tk.Label(
            wrapper,
            text=self._display_path(path),
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=(MONO, 10),
            wraplength=420,
            justify="left",
        ).pack(anchor="w", pady=(3, 5))

    def _build_manual_page(self) -> None:
        assert self.content is not None
        intro = tk.Frame(self.content, bg=COLORS["bg"])
        intro.pack(fill="x", pady=(0, 15))
        tk.Label(
            intro,
            text="Select a folder and decide where it should go.",
            bg=COLORS["bg"],
            fg=COLORS["text"],
            font=(FONT, 18, "bold"),
        ).pack(anchor="w")
        tk.Label(
            intro,
            text="This mode is intended for one-time archives, large media folders, and user-selected backups.",
            bg=COLORS["bg"],
            fg=COLORS["muted"],
            font=(FONT, 12),
        ).pack(anchor="w", pady=(4, 0))

        source_card = self._card(self.content, 18)
        source_card.pack(fill="x", pady=(0, 14))
        tk.Label(source_card, text="01  SOURCE FOLDER", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 13, "bold")).pack(anchor="w")
        source_row = tk.Frame(source_card, bg=COLORS["panel"])
        source_row.pack(fill="x", pady=(12, 0))
        self.source_entry = tk.Entry(
            source_row,
            textvariable=self.selected_source,
            bg=COLORS["panel_alt"],
            fg=COLORS["text"],
            insertbackground=COLORS["text"],
            relief="flat",
            bd=0,
            font=(MONO, 11),
        )
        self.source_entry.pack(side="left", fill="x", expand=True, ipady=11, padx=(0, 10))
        self._action_button(source_row, "BROWSE FOLDER", self._browse_source, False).pack(side="right")
        tk.Label(
            source_card,
            text="Choose the complete source folder. Its internal folder structure will be preserved.",
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=(FONT, 11),
        ).pack(anchor="w", pady=(9, 0))

        destination_card = self._card(self.content, 18)
        destination_card.pack(fill="x", pady=(0, 14))
        tk.Label(destination_card, text="02  BACKUP DESTINATIONS", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 13, "bold")).pack(anchor="w")
        tk.Label(
            destination_card,
            text="Select one or more destinations. A connection check will be added when the transfer engine is integrated.",
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=(FONT, 11),
        ).pack(anchor="w", pady=(4, 12))

        grid = tk.Frame(destination_card, bg=COLORS["panel"])
        grid.pack(fill="x")
        self.manual_status_labels: dict[str, tk.Label] = {}
        destination_items = list(MANUAL_DESTINATIONS.items())
        for index, (name, path) in enumerate(destination_items):
            row, col = divmod(index, 3)
            tile = tk.Frame(grid, bg=COLORS["panel_alt"], highlightbackground=COLORS["border"], highlightthickness=1, padx=10, pady=9)
            tile.grid(row=row, column=col, sticky="nsew", padx=(0, 6) if col < 2 else (6, 0), pady=4)
            grid.grid_columnconfigure(col, weight=1)
            check = tk.Checkbutton(
                tile, text=name, variable=self.destination_vars[name],
                bg=COLORS["panel_alt"], fg=COLORS["text"],
                activebackground=COLORS["panel_alt"], activeforeground=COLORS["accent"],
                selectcolor=COLORS["panel"], font=(FONT, 13, "bold"),
                anchor="w", cursor="hand2",
            )
            check.pack(anchor="w")
            tk.Label(tile, text=self._display_path(path), bg=COLORS["panel_alt"], fg=COLORS["muted"], font=(MONO, 8), wraplength=260, justify="left").pack(anchor="w", padx=(28, 0), pady=(5, 7))
            status = tk.Label(tile, text=self._destination_status(name), bg=COLORS["panel_alt"], fg=COLORS["blue"], font=(FONT, 9, "bold"), wraplength=260, justify="left")
            status.pack(anchor="w", padx=(28, 0))
            self.manual_status_labels[name] = status

        check_row = tk.Frame(destination_card, bg=COLORS["panel"])
        check_row.pack(fill="x", pady=(14, 0))
        self._action_button(check_row, "CHECK LOCAL PATH STATUS", self._refresh_manual_status, False).pack(side="left")
        tk.Label(check_row, text="Read-only check only. Cloud sync and write permission are not verified.", bg=COLORS["panel"], fg=COLORS["muted"], font=(FONT, 11)).pack(side="left", padx=14)

    def _refresh_manual_status(self) -> None:
        problem_states = {"SYNC FOLDER NOT DETECTED", "NETWORK VOLUME NOT MOUNTED", "SETUP REQUIRED - FOLDER NOT DETECTED", "LOCAL PARENT FOLDER NOT FOUND"}
        for name, label in getattr(self, "manual_status_labels", {}).items():
            status = self._destination_status(name)
            label.configure(text=status, fg=COLORS["amber"] if status in problem_states else COLORS["blue"])
        messagebox.showinfo(
            "Path Status Updated",
            "The local folder and network mount visibility check is complete. Cloud upload status and write permission have not been tested."
        )

    def _browse_source(self) -> None:
        selected = filedialog.askdirectory(title="Select Source Folder", mustexist=True)
        if selected:
            self.selected_source.set(selected)

    def _selected_destinations(self) -> list[tuple[str, Path | None]]:
        return [
            (name, path)
            for name, path in MANUAL_DESTINATIONS.items()
            if self.destination_vars[name].get()
        ]

    def _show_manual_review(self) -> None:
        source = self.selected_source.get().strip()
        destinations = self._selected_destinations()

        if not source:
            messagebox.showinfo("Source Required", "Choose a source folder before opening the review window.")
            return
        if not Path(source).is_dir():
            messagebox.showwarning("Source Not Available", "The selected source folder is not currently available.")
            return
        if not destinations:
            messagebox.showinfo("Destination Required", "Select at least one backup destination.")
            return

        self._open_review_window(
            mode="Manual Archive Backup",
            sources=[("Selected folder", Path(source))],
            destinations=destinations,
        )

    def _show_daily_review(self) -> None:
        destinations = [(name, path) for name, path in DAILY_DESTINATIONS.items()]
        self._open_review_window(
            mode="Daily Smart Backup",
            sources=[("Documents", DAILY_SOURCES[0]), ("Downloads", DAILY_SOURCES[1])],
            destinations=destinations,
        )

    def _open_review_window(self, mode: str, sources: list[tuple[str, Path]], destinations: list[tuple[str, Path | None]]) -> None:
        window = tk.Toplevel(self.root)
        window.title(f"SmartBackup | {mode} Review")
        window.geometry("1000x740")
        window.minsize(850, 620)
        window.configure(bg=COLORS["bg"])
        window.transient(self.root)
        window.grab_set()

        outer = tk.Frame(window, bg=COLORS["bg"], padx=25, pady=22)
        outer.pack(fill="both", expand=True)

        tk.Label(outer, text="REVIEW BEFORE BACKUP", bg=COLORS["bg"], fg=COLORS["accent"], font=(FONT, 11, "bold")).pack(anchor="w")
        tk.Label(outer, text=mode, bg=COLORS["bg"], fg=COLORS["text"], font=(FONT, 25, "bold")).pack(anchor="w", pady=(5, 4))
        tk.Label(
            outer,
            text="Confirm the source and selected destinations before the backup engine runs.",
            bg=COLORS["bg"],
            fg=COLORS["muted"],
            font=(FONT, 12),
        ).pack(anchor="w", pady=(0, 16))

        source_card = self._card(outer, 15)
        source_card.pack(fill="x", pady=(0, 12))
        tk.Label(source_card, text="SOURCE", bg=COLORS["panel"], fg=COLORS["blue"], font=(FONT, 11, "bold")).pack(anchor="w", pady=(0, 7))
        for label, path in sources:
            tk.Label(source_card, text=label, bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 18, "bold")).pack(anchor="w")
            tk.Label(source_card, text=str(path), bg=COLORS["panel"], fg=COLORS["muted"], font=(MONO, 10), wraplength=760, justify="left").pack(anchor="w", pady=(2, 8))

        dest_card = self._card(outer, 15)
        dest_card.pack(fill="both", expand=True, pady=(0, 12))
        tk.Label(dest_card, text="SELECTED DESTINATIONS", bg=COLORS["panel"], fg=COLORS["accent"], font=(FONT, 11, "bold")).pack(anchor="w", pady=(0, 8))
        review_status_labels: dict[str, tk.Label] = {}
        for label, path in destinations:
            row = tk.Frame(dest_card, bg=COLORS["panel"])
            row.pack(fill="x", pady=7)
            tk.Label(row, text="●", bg=COLORS["panel"], fg=COLORS["accent"], font=(FONT, 13)).pack(side="left")
            name_frame = tk.Frame(row, bg=COLORS["panel"])
            name_frame.pack(side="left", fill="x", expand=True, padx=(10, 10))
            tk.Label(name_frame, text=label, bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 13, "bold")).pack(anchor="w")
            tk.Label(name_frame, text=self._display_path(path), bg=COLORS["panel"], fg=COLORS["muted"], font=(MONO, 9), wraplength=770, justify="left").pack(anchor="w", pady=(3, 0))
            status = tk.Label(row, text="CHECK PENDING", bg=COLORS["amber_dark"], fg=COLORS["amber"], padx=10, pady=6, font=(FONT, 10, "bold"))
            status.pack(side="right")
            review_status_labels[label] = status

        def check_review_paths() -> None:
            problems = {"SYNC FOLDER NOT DETECTED", "NETWORK VOLUME NOT MOUNTED", "SETUP REQUIRED - FOLDER NOT DETECTED", "LOCAL PARENT FOLDER NOT FOUND"}
            for label, path in destinations:
                status_text = self._destination_status(label)
                is_problem = status_text in problems
                review_status_labels[label].configure(
                    text=status_text,
                    bg=COLORS["red_dark"] if is_problem else COLORS["blue_dark"],
                    fg=COLORS["red"] if is_problem else COLORS["blue"],
                )
            messagebox.showinfo(
                "Destination Path Check",
                "The local path and network mount visibility check is complete. This does not verify cloud upload, server write access, or file integrity."
            )


        item_card = self._card(outer, 15)
        item_card.pack(fill="x", pady=(0, 12))
        tk.Label(
            item_card,
            text="ITEM REVIEW",
            bg=COLORS["panel"],
            fg=COLORS["text"],
            font=(FONT, 11, "bold"),
        ).pack(anchor="w")
        placeholder_text = (
            "The daily scan results, file list, counts, and total size will appear here after the existing backup engine is connected."
            if mode == "Daily Smart Backup"
            else "The selected folder contents, file count, total size, and scan results will appear here after the archive scanner is connected."
        )
        tk.Label(
            item_card,
            text=placeholder_text,
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=(FONT, 11),
            wraplength=760,
            justify="left",
        ).pack(anchor="w", pady=(7, 0))

        notice = tk.Frame(outer, bg=COLORS["amber_dark"], padx=12, pady=10)
        notice.pack(fill="x", pady=(0, 13))
        tk.Label(
            notice,
            text="UI preview only. Path checks are read-only. No files are scanned, copied, uploaded, overwritten, or deleted.",
            bg=COLORS["amber_dark"],
            fg=COLORS["amber"],
            font=(FONT, 11, "bold"),
            wraplength=760,
            justify="left",
        ).pack(anchor="w")

        controls = tk.Frame(outer, bg=COLORS["bg"])
        controls.pack(fill="x")
        self._action_button(controls, "CANCEL", window.destroy, False).pack(side="right")
        self._action_button(
            controls,
            "CONTINUE TO PROGRESS PREVIEW",
            lambda: self._open_progress_preview(window),
            True,
        ).pack(side="right", padx=(0, 9))
        self._action_button(
            controls,
            "CHECK DESTINATION PATHS",
            check_review_paths,
            False,
        ).pack(side="left")


    def _open_progress_preview(self, parent: tk.Toplevel) -> None:
        window = tk.Toplevel(self.root)
        window.title("SmartBackup | Transfer Progress Preview")
        window.geometry("1000x740")
        window.minsize(850, 620)
        window.configure(bg=COLORS["bg"])
        window.transient(parent)
        window.grab_set()

        body = tk.Frame(window, bg=COLORS["bg"], padx=25, pady=22)
        body.pack(fill="both", expand=True)
        tk.Label(body, text="TRANSFER MONITOR", bg=COLORS["bg"], fg=COLORS["accent"], font=(FONT, 11, "bold")).pack(anchor="w")
        tk.Label(body, text="Backup Progress", bg=COLORS["bg"], fg=COLORS["text"], font=(FONT, 23, "bold")).pack(anchor="w", pady=(5, 3))
        tk.Label(body, text="Preview layout for file activity, destination results, and verification. Live updates will be connected to the backup engine.", bg=COLORS["bg"], fg=COLORS["muted"], font=(FONT, 12)).pack(anchor="w", pady=(0, 17))

        summary = tk.Frame(body, bg=COLORS["bg"])
        summary.pack(fill="x", pady=(0, 14))
        for value, label, accent in [
            ("0%", "Overall progress", COLORS["accent"]),
            ("0 / 0", "Files completed", COLORS["blue"]),
            ("—", "Estimated remaining", COLORS["amber"]),
        ]:
            card = self._card(summary, 14)
            card.pack(side="left", fill="both", expand=True, padx=(0, 9))
            tk.Label(card, text=value, bg=COLORS["panel"], fg=accent, font=(FONT, 23, "bold")).pack(anchor="w")
            tk.Label(card, text=label, bg=COLORS["panel"], fg=COLORS["muted"], font=(FONT, 11)).pack(anchor="w", pady=(3, 0))

        progress_card = self._card(body, 16)
        progress_card.pack(fill="x", pady=(0, 13))
        row = tk.Frame(progress_card, bg=COLORS["panel"])
        row.pack(fill="x")
        tk.Label(row, text="TRANSFER PROGRESS", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 18, "bold")).pack(side="left")
        tk.Label(row, text="0%", bg=COLORS["panel"], fg=COLORS["accent"], font=(FONT, 13, "bold")).pack(side="right")
        ttk.Progressbar(progress_card, maximum=100, value=0, style="Smart.Horizontal.TProgressbar").pack(fill="x", pady=(12, 8))
        tk.Label(progress_card, text="0 B transferred  ·  0 B remaining  ·  Speed: —", bg=COLORS["panel"], fg=COLORS["muted"], font=(FONT, 11)).pack(anchor="w")

        table_card = self._card(body, 12)
        table_card.pack(fill="both", expand=True, pady=(0, 13))
        tk.Label(table_card, text="FILE-BY-FILE ACTIVITY", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 18, "bold")).pack(anchor="w", pady=(0, 9))
        tree = ttk.Treeview(table_card, columns=("file", "destination", "status"), show="headings", style="Smart.Treeview", height=5)
        tree.heading("file", text="FILE")
        tree.heading("destination", text="DESTINATION")
        tree.heading("status", text="STATUS")
        tree.column("file", width=270, anchor="w")
        tree.column("destination", width=230, anchor="w")
        tree.column("status", width=150, anchor="center")
        tree.pack(fill="both", expand=True)
        tree.insert("", "end", values=("Waiting for transfer engine", "—", "NOT STARTED"))

        tk.Label(
            body,
            text="UI preview only — values are placeholders. No transfer is running.",
            bg=COLORS["bg"],
            fg=COLORS["amber"],
            font=(FONT, 11, "bold"),
        ).pack(anchor="w", pady=(0, 10))
        self._action_button(body, "CLOSE", window.destroy, False).pack(anchor="e")

    def _build_activity_page(self) -> None:
        assert self.content is not None
        summary = self._card(self.content, 20)
        summary.pack(fill="x", pady=(0, 14))
        tk.Label(summary, text="BACKUP HISTORY", bg=COLORS["panel"], fg=COLORS["text"], font=(FONT, 13, "bold")).pack(anchor="w")
        tk.Label(
            summary,
            text="The completed application will record each backup run, selected destinations, file-level outcomes, failed items, retry attempts, and checksum verification results.",
            bg=COLORS["panel"],
            fg=COLORS["muted"],
            font=(FONT, 12),
            wraplength=900,
            justify="left",
        ).pack(anchor="w", pady=(6, 0))

        table = self._card(self.content, 14)
        table.pack(fill="both", expand=True)
        columns = ("date", "mode", "destination", "result")
        tree = ttk.Treeview(table, columns=columns, show="headings", style="Smart.Treeview", height=8)
        headings = {
            "date": ("DATE / TIME", 170),
            "mode": ("BACKUP MODE", 190),
            "destination": ("DESTINATION", 270),
            "result": ("RESULT", 170),
        }
        for key, (label, width) in headings.items():
            tree.heading(key, text=label)
            tree.column(key, width=width, anchor="w")
        tree.pack(fill="both", expand=True)
        tree.insert("", "end", values=("—", "No recorded runs", "—", "Awaiting engine integration"))
        tk.Label(table, text="No real backup history is connected in this UI prototype.", bg=COLORS["panel"], fg=COLORS["subtle"], font=(FONT, 11)).pack(anchor="w", pady=(10, 0))


def main() -> None:
    root = tk.Tk()
    SmartBackupDashboard(root)
    root.mainloop()


if __name__ == "__main__":
    main()
